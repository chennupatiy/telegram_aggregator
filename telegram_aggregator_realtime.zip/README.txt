# Telegram Channel Aggregator with Dashboard and PIN Login

## Features
- Aggregates messages from multiple Telegram channels
- Real-time updates using Flask-SocketIO
- 6-digit PIN login for dashboard access
- SQLite database for message storage

## Prerequisites
- Python 3.8+
- pip
- Telegram API credentials (API_ID and API_HASH)
- Public channel usernames to monitor

## Setup Instructions

1. Install dependencies:
   pip install -r requirements.txt

2. Set environment variables:
   export TELEGRAM_API_ID=your_api_id
   export TELEGRAM_API_HASH=your_api_hash
   export TELEGRAM_CHANNELS=channel1,channel2
   export DASHBOARD_PIN=123456
   export FLASK_SECRET_KEY=your_secret_key

3. Run the app:
   python app.py

4. Access the dashboard:
   Open http://localhost:5000 in your browser and enter the 6-digit PIN.

## Notes
- The app stores messages in messages.db
- You can run this on a local Ubuntu server or deploy to the cloud
