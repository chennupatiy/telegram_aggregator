import os
import sqlite3
from flask import Flask, render_template_string, request, redirect, session
from flask_socketio import SocketIO, emit
from telethon import TelegramClient, events
from threading import Thread

# Load environment variables
DASHBOARD_PIN = os.getenv("DASHBOARD_PIN", "123456")
FLASK_SECRET_KEY = os.getenv("FLASK_SECRET_KEY", "supersecretkey")
API_ID = os.getenv("TELEGRAM_API_ID")
API_HASH = os.getenv("TELEGRAM_API_HASH")
CHANNELS = os.getenv("TELEGRAM_CHANNELS", "").split(",")

app = Flask(__name__)
app.secret_key = FLASK_SECRET_KEY
socketio = SocketIO(app)

# Initialize SQLite
conn = sqlite3.connect("messages.db", check_same_thread=False)
cursor = conn.cursor()
cursor.execute("""
CREATE TABLE IF NOT EXISTS messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    channel TEXT,
    sender_id TEXT,
    message TEXT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
)
""")
conn.commit()

# Telegram client
client = TelegramClient("aggregator_session", API_ID, API_HASH)

@client.on(events.NewMessage(chats=CHANNELS))
async def handler(event):
    sender = await event.get_sender()
    sender_id = getattr(sender, "username", "unknown")
    cursor.execute("INSERT INTO messages (channel, sender_id, message) VALUES (?, ?, ?)",
                   (event.chat.username, sender_id, event.raw_text))
    conn.commit()
    socketio.emit("new_message", {
        "channel": event.chat.username,
        "sender": sender_id,
        "message": event.raw_text
    })

def start_telegram():
    with client:
        client.run_until_disconnected()

@app.route("/", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        pin = request.form.get("pin")
        if pin == DASHBOARD_PIN:
            session["authenticated"] = True
            return redirect("/dashboard")
    return render_template_string("""
        <h2>Enter 6-digit PIN</h2>
        <form method="post">
            <input type="password" name="pin" maxlength="6" required>
            <input type="submit" value="Login">
        </form>
    """)

@app.route("/dashboard")
def dashboard():
    if not session.get("authenticated"):
        return redirect("/")
    cursor.execute("SELECT channel, sender_id, message, timestamp FROM messages ORDER BY id DESC LIMIT 50")
    messages = cursor.fetchall()
    return render_template_string("""
        <h2>Telegram Aggregator Dashboard</h2>
        <div id="messages">
            {% for m in messages %}
                <p><b>[{{m[0]}}]</b> {{m[1]}}: {{m[2]}} <i>{{m[3]}}</i></p>
            {% endfor %}
        </div>
        <script src="//cdnjs.cloudflare.com/ajax/libs/socket.io/4.0.0/socket.io.min.js"></script>
        <script>
            var socket = io();
            socket.on("new_message", function(data) {
                var p = document.createElement("p");
                p.innerHTML = "<b>[" + data.channel + "]</b> " + data.sender + ": " + data.message;
                document.getElementById("messages").prepend(p);
            });
        </script>
    """, messages=messages)

if __name__ == "__main__":
    Thread(target=start_telegram).start()
    socketio.run(app, host="0.0.0.0", port=5000)
